package com.lagou.boot;

import com.lagou.client.RPCConsumer;
import com.lagou.param.RpcRequest;
import com.lagou.result.RpcServer;
import com.lagou.service.IUserService;
import org.I0Itec.zkclient.IZkChildListener;
import org.I0Itec.zkclient.ZkClient;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.CopyOnWriteArrayList;

public class ConsumerBoot {

  //节点信息的格式是 host-port
  public static final ConcurrentMap<String, RpcServer> rpcServerMap = new ConcurrentHashMap<>();
  public static final String SERVER_CENTER_NODE = "/zk-servers";
  public static ZkClient zkClient = null;

  public static void main(String[] args) throws InterruptedException {
    zkClient = new ZkClient("127.0.0.1:2181");
    System.out.println("会话被创建了..");
    createRpcServer(null);
    zkClient.subscribeChildChanges(
        SERVER_CENTER_NODE,
        new IZkChildListener() {
          public void handleChildChange(String parentPath, List<String> list) throws Exception {
            createRpcServer(list);
          }
        });
    sendMessage();
  }

  /**
   * @author cjs
   * @description //创建远程服务信息
   * @date 2020/7/2 23:45
   * @param,childrenList
   * @return void
   */
  private static void createRpcServer(List<String> childrenList) throws InterruptedException {
    if (null == childrenList || childrenList.size() == 0) {
      return;
    }
    handleServerChange(childrenList);
  }

  /**
   * @author cjs
   * @description //节点更新
   * @date 2020/7/2 23:44
   * @param
   * @return void
   */
  private static void handleServerChange(List<String> childrenList) throws InterruptedException {
    List<String> addressList = new ArrayList<>();
    String addressStr = null;
    Object address = null;
    for (String child : childrenList) {
      if (zkClient.exists(SERVER_CENTER_NODE + "/" + child)) {
        address = zkClient.readData(SERVER_CENTER_NODE + "/" + child);
      } else {
        rpcServerMap.remove(addressStr);
        System.out.println("服务：" + addressStr + "下线了");
        continue;
      }
      addressStr = address.toString();
      if (null == rpcServerMap.get(addressStr)) {
        rpcServerMap.put(
            addressStr,
            new RpcServer(
                addressStr.split("-")[0], Integer.valueOf(addressStr.split("-")[1]), addressStr));
        System.out.println("服务：" + addressStr + "上线了");
      }
      addressList.add(addressStr);
    }
    Iterator<String> addressStrList = rpcServerMap.keySet().iterator();
    RpcServer rpcServer = null;
    while (addressStrList.hasNext()) {
      addressStr = addressStrList.next();
      if (addressList.contains(addressStr)) {
        continue;
      }
      rpcServer = rpcServerMap.get(addressStr);
      if (null != rpcServer && null != rpcServer.getChannelFuture()) {
        rpcServer.getChannelFuture().channel().close();
      }
      rpcServerMap.remove(addressStr);
      System.out.println("服务：" + addressStr + "下线了");
    }
  }
  /**
   * @author cjs
   * @description //发送信息
   * @date 2020/7/2 23:44
   * @param
   * @return void
   */
  private static void sendMessage() {
    while (true) {
      try {
        // 参数定义
        RpcRequest param = new RpcRequest();
        param.setRequestId("test");
        param.setClassName("com.lagou.service.UserServiceImpl");
        param.setMethodName("sayHello");
        param.setParameterTypes(new Class<?>[] {RpcRequest.class});
        param.setParameters(new Object[] {param});
        // 1.创建代理对象
        Optional<RpcServer> rpcServerOptional = rpcServerMap.values().parallelStream().findAny();
        if (!rpcServerOptional.isPresent()) {
          Thread.sleep(1000);
          continue;
        }
        RpcServer rpcServer = rpcServerOptional.get();
        IUserService userService =
            (IUserService) RPCConsumer.createProxy(IUserService.class, param, rpcServer);
        rpcServer.setUserService(userService);
        rpcServerMap.put(rpcServer.getAddress(), rpcServer);
        // 2.循环给服务器写数据
        String result = rpcServer.getUserService().sayHello(param);
        System.out.println("服务端信息：" + rpcServer.toString());
        System.out.println(result);
        Thread.sleep(2000);
      } catch (Exception e) {

      }
    }
  }
}
