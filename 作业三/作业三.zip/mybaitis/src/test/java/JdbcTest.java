import org.junit.Test;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author aleng
 * @version 1.0.0
 * @className Main
 * @description TODO
 * @createTime 2020年04月23日 11:54:00
 */
public class JdbcTest {

  @Test
  public void test() {
    testSelectOne();
    testSelectList();
  }

  private static void testSelectOne() {
    String url =
        "jdbc:mysql://192.168.10.193:3306/test?useUnicode=true&characterEncoding=UTF-8&autoReconnect=true&useSSL=false";
    Connection con = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;
    try {
      /**
       * 在DriverManager.getConnection之前需要先注册mysql驱动。连接数据库应该把该数据库的驱动注册进来（java.sql.DriverManager.registerDriver），
       * 如果改成oracle就要注册oracle的驱动。 在com.mysql.jdbc.Driver类中有下面这段代码：static { try {
       * java.sql.DriverManager.registerDriver(new Driver()); } catch (SQLException E) { throw new
       * RuntimeException("Can't register driver!"); } }
       */
      Class.forName("com.mysql.jdbc.Driver");
      con = DriverManager.getConnection(url, "root", "Ty123!@#");
      /**
       * statement和preparedstatement的区别： Statement可以正常访问数据库，适用于运行静态SQL 语句。 Statement 接口不接受参数。
       * PreparedStatement计划多次使用SQL 语句， PreparedStatement 接口运行时接受输入的参数。
       */
      String sql = "select * from user where name=?";
      preparedStatement = con.prepareStatement(sql);
      preparedStatement.setString(1, "张三");
      resultSet = preparedStatement.executeQuery();
      while (resultSet.next()) {
        int id = resultSet.getInt("id");
        String name = resultSet.getString("name");
        System.out.println("id: " + id);
        System.out.println("name: " + name);
      }
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      if (null != resultSet) {
        try {
          resultSet.close();
        } catch (SQLException e) {
          e.printStackTrace();
        }
      }
      if (null != preparedStatement) {
        try {
          preparedStatement.close();
        } catch (SQLException e) {
          e.printStackTrace();
        }
      }
      if (null != con) {
        try {
          con.close();
        } catch (SQLException e) {
          e.printStackTrace();
        }
      }
    }
  }

  private static void testSelectList() {
    String url =
        "jdbc:mysql://192.168.10.193:3306/test?useUnicode=true&characterEncoding=UTF-8&autoReconnect=true&useSSL=false";
    Connection con = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;
    try {
      /**
       * 在DriverManager.getConnection之前需要先注册mysql驱动。连接数据库应该把该数据库的驱动注册进来（java.sql.DriverManager.registerDriver），
       * 如果改成oracle就要注册oracle的驱动。 在com.mysql.jdbc.Driver类中有下面这段代码：static { try {
       * java.sql.DriverManager.registerDriver(new Driver()); } catch (SQLException E) { throw new
       * RuntimeException("Can't register driver!"); } }
       */
      Class.forName("com.mysql.jdbc.Driver");
      con = DriverManager.getConnection(url, "root", "Ty123!@#");
      /**
       * statement和preparedstatement的区别： Statement可以正常访问数据库，适用于运行静态SQL 语句。 Statement 接口不接受参数。
       * PreparedStatement计划多次使用SQL 语句， PreparedStatement 接口运行时接受输入的参数。
       */
      String sql = "select * from user";
      preparedStatement = con.prepareStatement(sql);
      resultSet = preparedStatement.executeQuery();
      List list = new ArrayList();
      ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
      int columnCount = resultSetMetaData.getColumnCount(); // 获取行的数量
      while (resultSet.next()) {
        Map rowData = new HashMap(); // 声明Map
        for (int i = 1; i <= columnCount; i++) {
          rowData.put(resultSetMetaData.getColumnName(i), resultSet.getObject(i)); // 获取键名及值
        }
        list.add(rowData);
      }
      System.out.println("list: " + list);
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      if (null != resultSet) {
        try {
          resultSet.close();
        } catch (SQLException e) {
          e.printStackTrace();
        }
      }
      if (null != preparedStatement) {
        try {
          preparedStatement.close();
        } catch (SQLException e) {
          e.printStackTrace();
        }
      }
      if (null != con) {
        try {
          con.close();
        } catch (SQLException e) {
          e.printStackTrace();
        }
      }
    }
  }
}
