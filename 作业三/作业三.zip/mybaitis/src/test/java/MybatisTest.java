import com.builder.SqlSessionFactoryBuilder;
import com.entity.User;
import com.factory.SqlSessionFactory;
import com.io.Resource;
import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.session.SqlSession;
import org.I0Itec.zkclient.IZkDataListener;
import org.I0Itec.zkclient.ZkClient;
import org.junit.Test;

import java.io.InputStream;
import java.util.List;

/**
 * @author aleng
 * @version 1.0.0
 * @className MybatisTest
 * @description TODO
 * @createTime 2020年04月23日 14:14:00
 */
public class MybatisTest {

  public static final String DB_NODE = "/zk-db";
  public static ZkClient zkClient = null;
  public static SqlSession sqlSession = null;
  public static SqlSessionFactoryBuilder sqlSessionFactoryBuilder = new SqlSessionFactoryBuilder();;

  @Test
  public void test() throws Exception {
    zkClient = new ZkClient("127.0.0.1:2181");
    if (!zkClient.exists(DB_NODE)) {
      zkClient.createPersistent(DB_NODE, "serverRoot");
    }
    // 注册监听
    zkClient.subscribeDataChanges(
        DB_NODE,
        new IZkDataListener() {
          public void handleDataChange(String s, Object o) throws Exception {
            //            sqlSession = getSqlSession(o.toString());
            ComboPooledDataSource dataSource =
                (ComboPooledDataSource) sqlSessionFactoryBuilder.getConfiguration().getDataSource();
            dataSource.setJdbcUrl(o.toString());
            dataSource.hardReset();
            System.out.println("数据库重置成功================================");
            List<User> userList = sqlSession.selectList("com.dao.IUserDao.getUserList");
            for (User user : userList) {
              System.out.println(user);
            }
          }

          @Override
          public void handleDataDeleted(String s) throws Exception {}
        });
    sqlSession = getSqlSession(null);
    List<User> userList = sqlSession.selectList("com.dao.IUserDao.getUserList");
    for (User user : userList) {
      System.out.println(user);
    }
    zkClient.writeData(
        DB_NODE,
        "jdbc:mysql://localhost:3306/test1?useAffectedRows=true&allowMultiQueries=true&allowPublicKeyRetrieval=true&useSSL=false&useUnicode=true&characterEncoding=UTF-8&serverTimezone=Asia/Shanghai");
    //
    //    IUserDao userDao = sqlSession.getMappper(IUserDao.class);
    //    Long userId = 10L;
    //    User user = new User();
    //    user.setId(userId);
    //    user.setName("张三");
    //    System.out.println(userDao.getUserByName(user));
    //    // 新增
    //    userDao.saveUser(user);
    //    // 修改
    //    user.setName("test1");
    //    userDao.updateById(user);
    //    // 查询
    //    userList = userDao.getUserList();
    //    for (User temp : userList) {
    //      System.out.println(temp);
    //    }
    //    // 删除
    //    userDao.deleteById(user);
    Thread.sleep(Integer.MAX_VALUE);
  }

  /**
   * @author cjs
   * @description //获取SqlSession
   * @date 2020/7/4 1:39
   * @param
   * @return com.session.SqlSession
   */
  private SqlSession getSqlSession(String url) throws Exception {
    InputStream inputStream = Resource.getResourceAsStream("sqlMapConfig.xml");
    SqlSessionFactory sqlSessionFactory = sqlSessionFactoryBuilder.create(inputStream, url);
    SqlSession sqlSession = sqlSessionFactory.openSession();
    return sqlSession;
  }
}
