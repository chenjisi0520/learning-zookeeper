package com.builder;

import com.config.Configuration;
import com.config.MappedStatement;
import com.constant.OperationMethodEnum;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.io.InputStream;
import java.util.List;

/**
 * @author aleng
 * @version 1.0.0
 * @className XMLMapperBuilder
 * @description TODO
 * @createTime 2020年04月24日 12:27:00
 */
public class XMLMapperBuilder {

  /*jdbc配置*/
  private Configuration configuration;

  public XMLMapperBuilder(Configuration configuration) {
    this.configuration = configuration;
  }

  public void parse(InputStream inputStream) throws DocumentException, ClassNotFoundException {
    Document document = new SAXReader().read(inputStream);
    Element rootElement = document.getRootElement();
    String namespace = rootElement.attributeValue("namespace");
    List<Element> select = rootElement.selectNodes("select");
    List<Element> update = rootElement.selectNodes("update");
    List<Element> insert = rootElement.selectNodes("insert");
    List<Element> delete = rootElement.selectNodes("delete");
    createStatementMap(namespace, select, OperationMethodEnum.SELECT);
    createStatementMap(namespace, update, OperationMethodEnum.UPDATE);
    createStatementMap(namespace, insert, OperationMethodEnum.INSERT);
    createStatementMap(namespace, delete, OperationMethodEnum.DELETE);
    //    MappedStatement mappedStatement = null;
    //    for (Element element : select) {
    //      String id = element.attributeValue("id");
    //      String paramterType = element.attributeValue("parameterType");
    //      String resultType = element.attributeValue("resultType");
    //      Class<?> paramterTypeClass = getClassType(paramterType);
    //      Class<?> resultTypeClass = getClassType(resultType);
    //      // statementId
    //      String key = namespace + "." + id;
    //      String textTrim = element.getTextTrim();
    //      // mappedStatement
    //      mappedStatement = new MappedStatement();
    //      mappedStatement.setId(id);
    //      mappedStatement.setParameterType(paramterTypeClass);
    //      mappedStatement.setResultType(resultTypeClass);
    //      mappedStatement.setSql(textTrim);
    //      mappedStatement.setMethod(OperationMethodEnum.SELECT);
    //      // configuration
    //      configuration.getStatementMap().put(key, mappedStatement);
    //    }
  }

  private void createStatementMap(
      String namespace, List<Element> elements, OperationMethodEnum method)
      throws DocumentException, ClassNotFoundException {
    MappedStatement mappedStatement = null;
    for (Element element : elements) {
      String id = element.attributeValue("id");
      String paramterType = element.attributeValue("parameterType");
      String resultType = element.attributeValue("resultType");
      Class<?> paramterTypeClass = getClassType(paramterType);
      Class<?> resultTypeClass = getClassType(resultType);
      // statementId
      String key = namespace + "." + id;
      String textTrim = element.getTextTrim();
      // mappedStatement
      mappedStatement = new MappedStatement();
      mappedStatement.setId(id);
      mappedStatement.setParameterType(paramterTypeClass);
      mappedStatement.setResultType(resultTypeClass);
      mappedStatement.setSql(textTrim);
      mappedStatement.setMethod(method);
      // configuration
      configuration.getStatementMap().put(key, mappedStatement);
    }
  }

  private Class<?> getClassType(String paramterType) throws ClassNotFoundException {
    if (null == paramterType) {
      return null;
    }
    Class<?> aClass = Class.forName(paramterType);
    return aClass;
  }
}
