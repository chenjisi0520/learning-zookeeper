package com.config;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

/**
 * @author aleng
 * @version 1.0.0
 * @className Configration
 * @description TODO
 * @createTime 2020年04月23日 14:40:00
 */
public class Configuration {
  /** 数据源* */
  private DataSource dataSource;
  /** StatementId（namespace+selectId） 和 Statement * */
  private Map<String, MappedStatement> statementMap = new HashMap<String, MappedStatement>();

  public DataSource getDataSource() {
    return dataSource;
  }

  public void setDataSource(DataSource dataSource) {
    this.dataSource = dataSource;
  }

  public Map<String, MappedStatement> getStatementMap() {
    return statementMap;
  }

  public void setStatementMap(Map<String, MappedStatement> statementMap) {
    this.statementMap = statementMap;
  }

  @Override
  public String toString() {
    return "Configuration{" + "dataSource=" + dataSource + ", statementMap=" + statementMap + '}';
  }
}
