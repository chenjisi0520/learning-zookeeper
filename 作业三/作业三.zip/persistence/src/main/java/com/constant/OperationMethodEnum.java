package com.constant;

/**
 * @author cjs
 * @version 1.0.0
 * @className OperationMethod
 * @description TODO
 * @createTime 2020年05月01日 00:12:00
 */
public enum OperationMethodEnum {
  INSERT,
  SELECT,
  DELETE,
  UPDATE
}
