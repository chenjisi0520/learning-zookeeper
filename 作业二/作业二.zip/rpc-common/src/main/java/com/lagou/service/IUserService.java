package com.lagou.service;

import com.lagou.param.RpcRequest;

public interface IUserService {

    public String sayHello(RpcRequest rpcRequest);

}
