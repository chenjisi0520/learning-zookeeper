package com.lagou;

import com.lagou.result.RpcServer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.TreeMap;

/**
 * @author cjs
 * @version 1.0.0
 * @className Test
 * @description TODO
 * @createTime 2020年07月04日 00:11:00
 */
public class Test {

  public static void main(String[] args) throws InterruptedException {
     List<RpcServer> list=new ArrayList<>();
      RpcServer rpcServer=new RpcServer();
      rpcServer.setMaintainTime(5);
      RpcServer rpcServer1=new RpcServer();
      rpcServer1.setMaintainTime(4);
      RpcServer rpcServer2=new RpcServer();
      rpcServer2.setMaintainTime(2);
      RpcServer rpcServer3=new RpcServer();
      rpcServer3.setMaintainTime(8);
      list.add(rpcServer);
      list.add(rpcServer1);
      list.add(rpcServer2);
      list.add(rpcServer3);
      Collections.sort(list);
      list.forEach(obj->System.out.println(obj));

//
  }
}
