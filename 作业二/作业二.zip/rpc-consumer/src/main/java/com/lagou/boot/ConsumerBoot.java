package com.lagou.boot;

import com.lagou.client.RPCConsumer;
import com.lagou.param.RpcRequest;
import com.lagou.result.RpcServer;
import com.lagou.service.IUserService;
import org.I0Itec.zkclient.IZkChildListener;
import org.I0Itec.zkclient.ZkClient;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.CopyOnWriteArrayList;

public class ConsumerBoot {

  // 节点信息的格式是 host-port
  public static final ConcurrentMap<String, RpcServer> rpcServerMap = new ConcurrentHashMap<>();
  public static final String SERVER_CENTER_NODE = "/zk-servers";
  public static ZkClient zkClient = null;

  public static void main(String[] args) throws InterruptedException {
    zkClient = new ZkClient("127.0.0.1:2181");
    System.out.println("会话被创建了..");
    createRpcServer(zkClient.getChildren(SERVER_CENTER_NODE));
    completeRpcServer();
    sendMessage();
  }

  /**
   * @author cjs
   * @description //创建远程服务信息
   * @date 2020/7/2 23:45
   * @param,childrenList
   * @return void
   */
  private static void createRpcServer(List<String> childrenList) throws InterruptedException {
    if (null == childrenList || childrenList.size() == 0) {
      return;
    }
    handleServerChange(childrenList);
  }

  /**
   * @author cjs
   * @description //节点更新
   * @date 2020/7/2 23:44
   * @param
   * @return void
   */
  private static void handleServerChange(List<String> childrenList) throws InterruptedException {
    List<String> addressList = new ArrayList<>();
    String addressStr = null;
    Object address = null;
    for (String child : childrenList) {
      if (zkClient.exists(SERVER_CENTER_NODE + "/" + child)) {
        address = zkClient.readData(SERVER_CENTER_NODE + "/" + child);
      } else {
        rpcServerMap.remove(addressStr);
        System.out.println("服务：" + addressStr + "下线了");
        continue;
      }
      addressStr = address.toString();
      if (null == rpcServerMap.get(addressStr)) {
        rpcServerMap.put(
            addressStr,
            new RpcServer(
                addressStr.split("-")[0], Integer.valueOf(addressStr.split("-")[1]), addressStr));
        System.out.println("服务：" + addressStr + "上线了");
      }
    }
  }

  private static void completeRpcServer() {
    RpcRequest param = new RpcRequest();
    param.setRequestId("test");
    param.setClassName("com.lagou.service.UserServiceImpl");
    param.setMethodName("sayHello");
    param.setParameterTypes(new Class<?>[] {RpcRequest.class});
    param.setParameters(new Object[] {param});
    // 1.创建代理对象
    for (RpcServer server : rpcServerMap.values()) {
      IUserService userService =
          (IUserService) RPCConsumer.createProxy(IUserService.class, param, server);
      server.setUserService(userService);
      new Thread(server).start();
    }
  }
  /**
   * @author cjs
   * @description //发送信息
   * @date 2020/7/2 23:44
   * @param
   * @return void
   */
  private static void sendMessage() throws InterruptedException {
    List<RpcServer> rpcServers = new ArrayList<>(rpcServerMap.values());
    while (true) {
      Thread.sleep(500);
      try {
        RpcRequest param = new RpcRequest();
        param.setRequestId("test");
        param.setClassName("com.lagou.service.UserServiceImpl");
        param.setMethodName("sayHello");
        param.setParameterTypes(new Class<?>[] {RpcRequest.class});
        param.setParameters(new Object[] {param});
        // 2.循环给服务器写数据
        Collections.sort(rpcServers);
        RpcServer rpcServer = rpcServers.get(0);
        long start = System.currentTimeMillis();
        rpcServer.setTimeMark(start);
        String result = rpcServer.getUserService().sayHello(param);
        long end = System.currentTimeMillis();
        int time = (int) (end - start) / 1000;
        System.out.println("请求的rpcServer：" + rpcServer);
        System.out.println("请求时长：" + time);
        rpcServer.setMaintainTime(time);
        Thread.sleep(2000);
      } catch (Exception e) {
      }
    }
  }
}
