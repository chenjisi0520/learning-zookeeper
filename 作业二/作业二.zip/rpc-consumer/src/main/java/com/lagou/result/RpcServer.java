package com.lagou.result;

import com.lagou.handler.UserClientHandler;
import com.lagou.param.RpcRequest;
import com.lagou.service.IUserService;
import io.netty.channel.ChannelFuture;

/**
 * @author cjs
 * @version 1.0.0
 * @className RpcServer
 * @description TODO
 * @createTime 2020年07月02日 23:19:00
 */
public class RpcServer implements Comparable<RpcServer>, Runnable {
  private ChannelFuture channelFuture;
  private IUserService userService;
  private String host;
  private int port;
  private String address;
  private int maintainTime = 0;
  private long timeMark = 0;

  public RpcServer() {}

  public RpcServer(String host, int port, String address) {
    this.host = host;
    this.port = port;
    this.address = address;
  }

  public ChannelFuture getChannelFuture() {
    return channelFuture;
  }

  public void setChannelFuture(ChannelFuture channelFuture) {
    this.channelFuture = channelFuture;
  }

  public IUserService getUserService() {
    return userService;
  }

  public void setUserService(IUserService userService) {
    this.userService = userService;
  }

  public String getHost() {
    return host;
  }

  public void setHost(String host) {
    this.host = host;
  }

  public int getPort() {
    return port;
  }

  public void setPort(int port) {
    this.port = port;
  }

  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  public int getMaintainTime() {
    return maintainTime;
  }

  public void setMaintainTime(int maintainTime) {
    this.maintainTime = maintainTime;
  }

  public long getTimeMark() {
    return timeMark;
  }

  public void setTimeMark(long timeMark) {
    this.timeMark = timeMark;
  }

  @Override
  public String toString() {
    return "RpcServer{"
        + "userService="
        + userService
        + ", host='"
        + host
        + '\''
        + ", port="
        + port
        + ", address='"
        + address
        + '\''
        + ", maintainTime="
        + maintainTime
        + '}';
  }

  @Override
  public int compareTo(RpcServer o) {
    return this.getMaintainTime() - o.getMaintainTime();
  }

  @Override
  public void run() {
    while (true) {
      try {
        Thread.sleep(1000);
      } catch (InterruptedException e) {
        e.printStackTrace();
      }
      long now = System.currentTimeMillis();
      if (now - timeMark > 5000) {
        this.setMaintainTime(0);
        this.setTimeMark(now);
        System.out.println(this.toString() + "超过5s，清0");
      }
    }
  }
}
