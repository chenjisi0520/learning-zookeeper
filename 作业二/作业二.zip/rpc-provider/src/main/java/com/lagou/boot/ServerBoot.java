package com.lagou.boot;

import com.lagou.service.UserServiceImpl;
import io.netty.channel.ChannelFuture;
import org.I0Itec.zkclient.ZkClient;

import java.util.List;

public class ServerBoot implements Runnable {

  public static final String SERVER_CENTER_NODE = "/zk-servers";
  private ZkClient client = null;
  private int port = 0;

  public static void main(String[] args) throws InterruptedException {
    ZkClient zkClient = new ZkClient("127.0.0.1:2181");
    if (!zkClient.exists(SERVER_CENTER_NODE)) {
      zkClient.createPersistent(SERVER_CENTER_NODE, "serverRoot");
    }
    Thread test1 = new Thread(new ServerBoot(8999));
    test1.start();
    Thread test2 = new Thread(new ServerBoot(8888));
    test2.start();
  }

  @Override
  public void run() {
    client = new ZkClient("127.0.0.1:2181");
    ChannelFuture channelFuture = null;
    try {
      channelFuture = UserServiceImpl.startServer("127.0.0.1", port);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    client.createEphemeral(SERVER_CENTER_NODE + "/" + port, "127.0.0.1-" + port);
  }

  public ServerBoot(int port) {
    this.port = port;
  }

  public static final void sleep(int ms) {
    try {
      Thread.sleep(ms);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }
}
